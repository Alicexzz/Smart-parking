package com.example.smart_parking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
