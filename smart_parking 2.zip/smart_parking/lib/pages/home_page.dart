import 'package:flutter/material.dart';
import 'package:smart_parking/pages/home_index.dart';
import 'package:smart_parking/pages/parking_index.dart';
import 'package:smart_parking/pages/personal_index.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<BottomNavigationBarItem> bottomNavItems = [
    const BottomNavigationBarItem(
      icon: Icon(Icons.home),
      label: ""
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.car_crash_outlined),
      label: ""
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.person_pin),
      label: ""
    ),
  ];
  final pages = [HomeIndex(), ParkingIndex(), PersonalIndex()];

  int currentIndex = 0;


  @override
  Widget build(BuildContext context) {
    (pages[0] as HomeIndex).onLeftPressed = (){
      _changePage(1);
    };
    (pages[0] as HomeIndex).onRightPressed = (){
      _changePage(2);
    };
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        items: bottomNavItems,
        currentIndex: currentIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (index) {
          _changePage(index);
        },
      ),
      body: pages[currentIndex],
    );
  }

  void _changePage(int index) {
    if (index != currentIndex) {
      setState(() {
        currentIndex = index;
      });
    }
  }

}
