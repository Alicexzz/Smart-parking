import 'package:flutter/material.dart';

class HomeIndex extends StatefulWidget {
  VoidCallback? onLeftPressed;
  VoidCallback? onRightPressed;
  HomeIndex({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _HomeIndexState();

}

class _HomeIndexState extends State<HomeIndex> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Spacer(flex: 4,),
        Image.asset("assets/images/shouye.png", width: double.infinity, fit: BoxFit.fitWidth,),
        const Spacer(flex: 4,),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            ElevatedButton(onPressed: widget.onLeftPressed, child: const Padding(padding: EdgeInsets.only(left: 10, right: 10, top: 20, bottom: 20), child: Text("Car Reservation"),)),
            ElevatedButton(onPressed: widget.onRightPressed, child: const Padding(padding: EdgeInsets.only(left: 10, right: 10, top: 20, bottom: 20), child: Text("Personal Information"),)),
          ],
        ),
        const Spacer(flex: 1,),
      ],
    );
  }

}