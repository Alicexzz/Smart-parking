import 'package:flutter/material.dart';

class PersonalIndex extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _PersonalIndexState();
}

class _PersonalIndexState extends State<PersonalIndex> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Personal Center"),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Spacer(flex: 2,),
          Row(
            children: [
              const Spacer(),
              ClipOval(
                  child: Image.asset("assets/images/user_icon.png",
                      width: 200, height: 200, fit: BoxFit.cover)),
              const Spacer(),
            ],
          ),
          const Spacer(),
          buildLabelWidget("Name", "138xxxxxxxx"),
          const SizedBox(height: 20,),
          buildLabelWidget("Phone", "138xxxxxxxx"),
          const SizedBox(height: 20,),
          buildLabelWidget("Plate", "138xxxxxxxx"),
          const SizedBox(height: 20,),
          buildLabelWidget("Color", "138xxxxxxxx"),
          const SizedBox(height: 20,),
          buildLabelWidget("Account Balance", "138xxxxxxxx"),
          const Spacer(flex: 2,),
        ],
      ),
    );
  }

  Widget buildLabelWidget(String name, String value) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            const Spacer(),
            Text(
              "$name#  ",
              style: TextStyle(color: Colors.amber, fontSize: 18),
            ),
            Text(
              value,
              style: TextStyle(color: Colors.black, fontSize: 18),
            ),
            const Spacer()
          ],
        ),
      ),
    );
  }
}
