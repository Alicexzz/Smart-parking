import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';

class ParkingIndex extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _ParkingIndexState();

}

class _ParkingIndexState extends State<ParkingIndex> {

  List listData = [
    {
      "id": "1",
      "hasCar": GetStorage().hasData("1")?GetStorage().read("1"):false,
    },
    {
      "id": "2",
      "hasCar": GetStorage().hasData("2")?GetStorage().read("2"):false,
    },
    {
      "id": "3",
      "hasCar": GetStorage().hasData("3")?GetStorage().read("3"):false,
    },
    {
      "id": "4",
      "hasCar": GetStorage().hasData("4")?GetStorage().read("4"):false,
    },
    {
      "id": "5",
      "hasCar": GetStorage().hasData("5")?GetStorage().read("5"):false,
    },
    {
      "id": "6",
      "hasCar": GetStorage().hasData("6")?GetStorage().read("6"):false,
    },
    {
      "id": "7",
      "hasCar": GetStorage().hasData("7")?GetStorage().read("7"):false,
    },
    {
      "id": "8",
      "hasCar": GetStorage().hasData("8")?GetStorage().read("8"):false,
    },

  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Parking Info ..."),),
      body: Column(
        children: [
          const Spacer(),
          Expanded(
              child: GridView.count(
                crossAxisCount: 4,
                padding: const EdgeInsets.all(10),
                crossAxisSpacing: 10,
                //设置主轴间距
                mainAxisSpacing: 10,
                children: _getData(),
              )
          ),
          const Spacer(),
        ],
      ),
    );
  }

  List<Widget> _getData() {
    List<Widget> list = [];
    for (var i = 0; i < listData.length; i++) {
      list.add(
        GestureDetector(
          child: Image.asset(listData[i]['hasCar']?"assets/images/card_blue.png":"assets/images/card_red.png"),
          onTap: () {
            GetStorage().write('${i + 1}', !listData[i]['hasCar']);
            setState(() {
              listData[i]['hasCar'] = !listData[i]['hasCar'];
            });
          },
        )
      );
    }
    return list;
  }

}